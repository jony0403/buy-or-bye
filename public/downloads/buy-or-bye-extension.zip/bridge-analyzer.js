/** ?? ???(localhost) ? ?? storage ??? */
(() => {
  const PORTS = [3920, 3921];

  function isAnalyzerPage() {
    const host = location.hostname;
    if (host === '127.0.0.1' || host === 'localhost') {
      return PORTS.includes(Number(location.port));
    }
    // championship / deployed analyzer
    if (host.includes('buy-or-bye') && host.includes('railway.app')) return true;
    if (typeof BUY_OR_BYE_ANALYZER_ORIGINS !== 'undefined') {
      return BUY_OR_BYE_ANALYZER_ORIGINS.includes(location.origin);
    }
    return false;
  }

  if (!isAnalyzerPage()) return;
  if (globalThis.__buyOrByeAnalyzerBridgeInstalled) return;
  globalThis.__buyOrByeAnalyzerBridgeInstalled = true;

  document.addEventListener('ulsa-ai-settings', (ev) => {
    const d = ev.detail;
    if (!d || !d.apiKey) return;
    try {
      chrome.storage.local.set({
        ulsaOpenAiApiKey: d.apiKey,
        ulsaOpenAiModel: d.model || 'gemini-3.5-flash-lite',
        ulsaOpenAiVerifiedAt: d.verifiedAt || Date.now(),
        ulsaGeminiApiKey: d.apiKey,
        ulsaGeminiModel: d.model || 'gemini-3.5-flash-lite',
        ulsaGeminiVerifiedAt: d.verifiedAt || Date.now(),
      });
    } catch {
      /* extension reloaded */
    }
  });

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data || ev.data.type !== 'ULSA_AI_SETTINGS' || !ev.data.apiKey) return;
    try {
      chrome.storage.local.set({
        ulsaOpenAiApiKey: ev.data.apiKey,
        ulsaOpenAiModel: ev.data.model || 'gemini-3.5-flash-lite',
        ulsaOpenAiVerifiedAt: ev.data.verifiedAt || Date.now(),
        ulsaGeminiApiKey: ev.data.apiKey,
        ulsaGeminiModel: ev.data.model || 'gemini-3.5-flash-lite',
        ulsaGeminiVerifiedAt: ev.data.verifiedAt || Date.now(),
      });
    } catch {
      /* extension reloaded */
    }
  });

  function attachComps(latest, comps) {
    if (!latest || !comps?.forItemKey) return latest;
    const key = `${latest.platform}:${latest.itemId}`;
    if (comps.forItemKey !== key) return latest;
    return { ...latest, comps };
  }

  function pushToPage() {
    try {
      chrome.storage.local.get(['marketScrapeLatest', 'marketScrapeHistory', 'marketScrapeComps'], (res) => {
        const latest = attachComps(res.marketScrapeLatest, res.marketScrapeComps);
        window.postMessage(
          {
            type: 'MARKET_SCRAPE_BRIDGE',
            latest,
            history: res.marketScrapeHistory || [],
            comps: res.marketScrapeComps || null,
          },
          '*'
        );
      });
    } catch {
      /* extension reloaded */
    }
  }

  function postSearchTabsResult(payload) {
    window.postMessage(
      {
        type: 'MARKET_SCRAPE_SEARCH_TABS_RESULT',
        ...payload,
      },
      '*'
    );
  }

  function postUrlImportResult(payload) {
    window.postMessage(
      {
        type: 'MARKET_SCRAPE_URL_IMPORT_RESULT',
        ...payload,
      },
      '*'
    );
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'ULSA_EXT_PING') return;
    window.postMessage({ type: 'ULSA_EXT_PONG', at: Date.now() }, '*');
  });

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'MARKET_SCRAPE_REQUEST') return;
    pushToPage();
  });

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'MARKET_SCRAPE_OPEN_SEARCH_TABS') return;
    const now = Date.now();
    const qKey = JSON.stringify(Array.isArray(ev.data.queries) ? ev.data.queries : [ev.data.query || '']);
    if (
      globalThis.__buyOrByeBridgeSearchAt &&
      now - globalThis.__buyOrByeBridgeSearchAt < 2500 &&
      globalThis.__buyOrByeBridgeSearchKey === qKey
    ) {
      return;
    }
    globalThis.__buyOrByeBridgeSearchAt = now;
    globalThis.__buyOrByeBridgeSearchKey = qKey;
    const queries = Array.isArray(ev.data.queries)
      ? ev.data.queries.map((q) => String(q || '').trim()).filter(Boolean)
      : [String(ev.data.query || '').trim()].filter(Boolean);
    if (!queries.length) {
      window.postMessage({ type: 'MARKET_SCRAPE_SEARCH_TABS_RESULT', ok: false, error: '???? ?????.' }, '*');
      return;
    }
    const forItemKey = String(ev.data.forItemKey || '').trim();
    const listing = ev.data.listing && typeof ev.data.listing === 'object' ? ev.data.listing : null;

    const sendOpen = () => {
      try {
        chrome.runtime.sendMessage(
          { type: 'OPEN_SEARCH_TABS', query: queries[0], queries, forItemKey: forItemKey || undefined },
          (res) => {
            const runtimeError = chrome.runtime.lastError?.message || '';
            postSearchTabsResult({
              ok: Boolean(res?.ok) && !runtimeError,
              error: runtimeError || res?.error || '',
              query: res?.query || queries[0],
              queries: res?.queries || queries,
              forItemKey: res?.forItemKey || forItemKey,
            });
          }
        );
      } catch (e) {
        postSearchTabsResult({
          ok: false,
          error: e instanceof Error ? e.message : String(e),
          query: queries[0],
          queries,
          forItemKey,
        });
      }
    };

    // ??/? ?? ??? ?? ??? ??? storage latest? ?? ???
    if (listing?.platform && listing?.itemId) {
      try {
        chrome.storage.local.get(['marketScrapeHistory'], (res) => {
          const history = Array.isArray(res.marketScrapeHistory) ? res.marketScrapeHistory : [];
          const key = `${listing.platform}:${listing.itemId}`;
          const nextHistory = [listing, ...history.filter((h) => `${h.platform}:${h.itemId}` !== key)].slice(0, 40);
          chrome.storage.local.set(
            {
              marketScrapeLatest: listing,
              marketScrapeHistory: nextHistory,
            },
            () => sendOpen()
          );
        });
      } catch {
        sendOpen();
      }
    } else {
      sendOpen();
    }
  });

window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'MARKET_SCRAPE_IMPORT_URL') return;
    const url = String(ev.data.url || '').trim();
    const now = Date.now();
    if (url && globalThis.__buyOrByeBridgeImportAt && now - globalThis.__buyOrByeBridgeImportAt < 2500 && globalThis.__buyOrByeBridgeImportUrl === url) return;
    globalThis.__buyOrByeBridgeImportAt = now;
    globalThis.__buyOrByeBridgeImportUrl = url;
    if (!url) {
      postUrlImportResult({ ok: false, error: 'URL? ?????.' });
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: 'OPEN_LISTING_URL', url }, (res) => {
        const runtimeError = chrome.runtime.lastError?.message || '';
        postUrlImportResult({
          ok: Boolean(res?.ok) && !runtimeError,
          error: runtimeError || res?.error || '',
          url,
          platform: res?.platform || '',
          listing: res?.listing || null,
        });
        if (res?.ok) pushToPage();
      });
    } catch (e) {
      postUrlImportResult({ ok: false, error: e instanceof Error ? e.message : String(e), url });
    }
  });

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'MARKET_SCRAPE_CLEAR_COMPS') return;
    try {
      chrome.storage.local.set({ marketScrapeComps: null }, () => {
        window.postMessage({ type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: true, action: 'clear-comps' }, '*');
        pushToPage();
      });
    } catch (e) {
      window.postMessage(
        { type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: false, error: e instanceof Error ? e.message : String(e) },
        '*'
      );
    }
  });

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'MARKET_SCRAPE_DELETE_HISTORY') return;
    const key = String(ev.data.key || '');
    if (!key) return;
    try {
      chrome.storage.local.get(['marketScrapeLatest', 'marketScrapeHistory', 'marketScrapeComps'], (res) => {
        const history = Array.isArray(res.marketScrapeHistory) ? res.marketScrapeHistory : [];
        const nextHistory = history.filter((item) => `${item.platform}:${item.itemId}` !== key);
        const latestKey = res.marketScrapeLatest
          ? `${res.marketScrapeLatest.platform}:${res.marketScrapeLatest.itemId}`
          : '';
        const nextLatest = latestKey === key ? nextHistory[0] || null : res.marketScrapeLatest || null;
        const nextComps = res.marketScrapeComps?.forItemKey === key ? null : res.marketScrapeComps || null;
        chrome.storage.local.set(
          {
            marketScrapeLatest: nextLatest,
            marketScrapeHistory: nextHistory,
            marketScrapeComps: nextComps,
          },
          () => {
            window.postMessage({ type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: true, action: 'delete-history' }, '*');
            pushToPage();
          }
        );
      });
    } catch (e) {
      window.postMessage(
        { type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: false, error: e instanceof Error ? e.message : String(e) },
        '*'
      );
    }
  });

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'MARKET_SCRAPE_PROMOTE_HISTORY') return;
    const key = String(ev.data.key || '');
    if (!key) return;
    try {
      chrome.storage.local.get(['marketScrapeHistory'], (res) => {
        const history = Array.isArray(res.marketScrapeHistory) ? res.marketScrapeHistory : [];
        const found = history.find((item) => `${item.platform}:${item.itemId}` === key);
        if (!found) return;
        const nextHistory = [found, ...history.filter((item) => `${item.platform}:${item.itemId}` !== key)];
        chrome.storage.local.set(
          {
            marketScrapeLatest: found,
            marketScrapeHistory: nextHistory,
          },
          () => {
            window.postMessage({ type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: true, action: 'promote-history' }, '*');
            pushToPage();
          }
        );
      });
    } catch (e) {
      window.postMessage(
        { type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: false, error: e instanceof Error ? e.message : String(e) },
        '*'
      );
    }
  });

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.data?.type !== 'MARKET_SCRAPE_CLEAR_HISTORY') return;
    try {
      chrome.storage.local.set(
        {
          marketScrapeLatest: null,
          marketScrapeHistory: [],
          marketScrapeComps: null,
        },
        () => {
          window.postMessage({ type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: true, action: 'clear-history' }, '*');
          pushToPage();
        }
      );
    } catch (e) {
      window.postMessage(
        { type: 'MARKET_SCRAPE_MUTATION_RESULT', ok: false, error: e instanceof Error ? e.message : String(e) },
        '*'
      );
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.marketScrapeLatest || changes.marketScrapeHistory || changes.marketScrapeComps) pushToPage();
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'PUSH_ANALYZER') {
      pushToPage();
      return true;
    }
    return undefined;
  });

  pushToPage();
})();
